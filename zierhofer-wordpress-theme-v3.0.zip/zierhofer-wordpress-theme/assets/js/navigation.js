/**
 * Navigation JavaScript
 * 
 * @package Zierhofer
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        
        // Mobile menu toggle
        $('.menu-toggle').on('click', function() {
            var $this = $(this);
            var $nav = $('#site-navigation');
            
            $this.toggleClass('active');
            $nav.toggleClass('active');
            
            var expanded = $this.attr('aria-expanded') === 'true' || false;
            $this.attr('aria-expanded', !expanded);
            
            // Prevent body scroll when menu is open
            if ($nav.hasClass('active')) {
                $('body').addClass('menu-open');
            } else {
                $('body').removeClass('menu-open');
            }
        });

        // Close mobile menu when clicking outside
        $(document).on('click', function(e) {
            var $nav = $('#site-navigation');
            var $toggle = $('.menu-toggle');
            
            if ($nav.hasClass('active') && !$nav.is(e.target) && $nav.has(e.target).length === 0 && !$toggle.is(e.target) && $toggle.has(e.target).length === 0) {
                $toggle.removeClass('active');
                $nav.removeClass('active');
                $toggle.attr('aria-expanded', 'false');
                $('body').removeClass('menu-open');
            }
        });

        // Close mobile menu on window resize
        $(window).on('resize', function() {
            if ($(window).width() > 768) {
                $('.menu-toggle').removeClass('active');
                $('#site-navigation').removeClass('active');
                $('.menu-toggle').attr('aria-expanded', 'false');
                $('body').removeClass('menu-open');
            }
        });

        // Add dropdown toggle for submenus
        $('.main-navigation .menu-item-has-children > a').after('<button class="submenu-toggle" aria-expanded="false"><span class="screen-reader-text">Submenu</span><svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="M4 6l4 4 4-4z"/></svg></button>');

        $('.submenu-toggle').on('click', function(e) {
            e.preventDefault();
            var $this = $(this);
            var $submenu = $this.siblings('.sub-menu');
            
            $this.toggleClass('active');
            $submenu.toggleClass('active');
            
            var expanded = $this.attr('aria-expanded') === 'true' || false;
            $this.attr('aria-expanded', !expanded);
        });

        // Keyboard navigation
        $('.main-navigation a').on('focus', function() {
            $(this).parents('li').addClass('focus');
        }).on('blur', function() {
            $(this).parents('li').removeClass('focus');
        });

        // Add active class to current menu item
        var currentUrl = window.location.href;
        $('.main-navigation a').each(function() {
            if (this.href === currentUrl) {
                $(this).parent('li').addClass('current-menu-item');
            }
        });

    });

})(jQuery);
