/**
 * Customizer live preview
 * 
 * @package Zierhofer
 */

(function($) {
    'use strict';

    // Company name
    wp.customize('zierhofer_company_name', function(value) {
        value.bind(function(newval) {
            $('.site-title').text(newval);
        });
    });

    // Company tagline
    wp.customize('zierhofer_company_tagline', function(value) {
        value.bind(function(newval) {
            $('.site-description, .hero-subtitle').text(newval);
        });
    });

    // Phone number
    wp.customize('zierhofer_phone', function(value) {
        value.bind(function(newval) {
            $('.contact-phone').text(newval);
        });
    });

    // Email
    wp.customize('zierhofer_email', function(value) {
        value.bind(function(newval) {
            $('.contact-email').text(newval);
        });
    });

    // Hero title
    wp.customize('zierhofer_hero_title', function(value) {
        value.bind(function(newval) {
            $('.hero-title').text(newval);
        });
    });

    // Hero subtitle
    wp.customize('zierhofer_hero_subtitle', function(value) {
        value.bind(function(newval) {
            $('.hero-subtitle').text(newval);
        });
    });

    // Footer copyright
    wp.customize('zierhofer_footer_copyright', function(value) {
        value.bind(function(newval) {
            $('.footer-bottom p:first-child').text(newval);
        });
    });

})(jQuery);
