<?php
/**
 * Template Name: Karriere
 * Template for the career page
 *
 * @package Zierhofer
 */

get_header();
?>

<main id="primary" class="site-main page-karriere">
    
    <section class="hero-section section">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">Karriere</h1>
                <p class="hero-subtitle">Werden Sie Teil unseres Teams</p>
            </div>
        </div>
    </section>

    <section class="training-section section">
        <div class="container">
            <div class="row">
                <div class="col col-half">
                    <div class="section-title underline-3">
                        <h2>
                            <span class="main-head">Ausbildung</span>
                            <span class="sub-head">als Gas-, Wasser- und Heizungsinstallateur</span>
                        </h2>
                    </div>
                    <div class="content-block">
                        <p>Was wäre die Menschheit ohne das Handwerk? Unser Ziel ist es, Jugendliche für den Handwerksberuf zu begeistern und ihnen eine Perspektive für die Zukunft zu bieten.</p>
                        <p>Wir suchen ständig engagierte Anlagenmechaniker und Auszubildende – bewerben Sie sich jetzt und unterstützen Sie unser Team!</p>
                    </div>
                </div>
                <div class="col col-half">
                    <div class="image-circle">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/01/sanatec-ausbildung-500x500.png'); ?>" alt="Ausbildung">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="jobs-section section">
        <div class="container">
            <div class="section-title underline-2 text-center">
                <h2>
                    <span class="main-head">Offene Stellen</span>
                    <span class="sub-head">Ihre Chance bei Sana Tec</span>
                </h2>
            </div>

            <div class="jobs-grid">
                <div class="job-item">
                    <h3>Anlagenmechaniker (m/w/d)</h3>
                    <p><strong>Vollzeit</strong></p>
                    <p>Wir suchen einen erfahrenen Anlagenmechaniker für Sanitär-, Heizungs- und Klimatechnik zur Verstärkung unseres Teams.</p>
                    <ul>
                        <li>Installation und Wartung von Heizungsanlagen</li>
                        <li>Sanitärinstallationen</li>
                        <li>Gasinstallationen</li>
                        <li>Kundenbetreuung</li>
                    </ul>
                    <a href="<?php echo esc_url(home_url('/kontakt')); ?>" class="btn">Jetzt bewerben</a>
                </div>

                <div class="job-item">
                    <h3>Auszubildender (m/w/d)</h3>
                    <p><strong>Ausbildung</strong></p>
                    <p>Starte deine Karriere als Anlagenmechaniker für Sanitär-, Heizungs- und Klimatechnik bei uns!</p>
                    <ul>
                        <li>3,5-jährige Ausbildung</li>
                        <li>Praxisnahe Ausbildung im Meisterbetrieb</li>
                        <li>Übernahmechancen nach der Ausbildung</li>
                        <li>Attraktive Vergütung</li>
                    </ul>
                    <a href="<?php echo esc_url(home_url('/kontakt')); ?>" class="btn">Jetzt bewerben</a>
                </div>

                <div class="job-item">
                    <h3>Geselle (m/w/d)</h3>
                    <p><strong>Vollzeit</strong></p>
                    <p>Wir suchen motivierte Gesellen zur Unterstützung unseres Teams bei vielfältigen Projekten.</p>
                    <ul>
                        <li>Montage und Installation</li>
                        <li>Wartung und Reparatur</li>
                        <li>Teamarbeit auf Baustellen</li>
                        <li>Weiterbildungsmöglichkeiten</li>
                    </ul>
                    <a href="<?php echo esc_url(home_url('/kontakt')); ?>" class="btn">Jetzt bewerben</a>
                </div>
            </div>
        </div>
    </section>

    <section class="benefits-section section">
        <div class="container">
            <div class="section-title underline-2 text-center">
                <h2>
                    <span class="main-head">Ihre Vorteile</span>
                    <span class="sub-head">Warum Sana Tec?</span>
                </h2>
            </div>

            <div class="benefits-grid">
                <div class="benefit-item">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                    <h3>Meisterbetrieb</h3>
                    <p>Lernen Sie von erfahrenen Meistern in einem etablierten Fachbetrieb</p>
                </div>

                <div class="benefit-item">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                    <h3>Weiterbildung</h3>
                    <p>Regelmäßige Schulungen und Weiterbildungsmöglichkeiten</p>
                </div>

                <div class="benefit-item">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                    <h3>Teamgeist</h3>
                    <p>Arbeiten Sie in einem motivierten und kollegialen Team</p>
                </div>

                <div class="benefit-item">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                    <h3>Faire Bezahlung</h3>
                    <p>Attraktive Vergütung und zusätzliche Benefits</p>
                </div>

                <div class="benefit-item">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                    <h3>Moderne Ausstattung</h3>
                    <p>Arbeiten Sie mit modernen Werkzeugen und Technologien</p>
                </div>

                <div class="benefit-item">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                    <h3>Zukunftsperspektive</h3>
                    <p>Langfristige Karrierechancen in einem wachsenden Unternehmen</p>
                </div>
            </div>
        </div>
    </section>

    <section class="application-section section">
        <div class="container">
            <div class="section-title underline-2 text-center">
                <h2>
                    <span class="main-head">Bewerbung</span>
                    <span class="sub-head">So bewerben Sie sich</span>
                </h2>
            </div>

            <div class="content-block text-center">
                <p>Senden Sie Ihre vollständigen Bewerbungsunterlagen (Anschreiben, Lebenslauf, Zeugnisse) per E-Mail an:</p>
                <p><strong><?php zierhofer_display_email(); ?></strong></p>
                <p>Oder nutzen Sie unser Kontaktformular:</p>
                <a href="<?php echo esc_url(home_url('/kontakt')); ?>" class="btn btn-primary">Zum Kontaktformular</a>
            </div>
        </div>
    </section>

    <?php
    while (have_posts()) :
        the_post();
        if (get_the_content()) :
            ?>
            <section class="page-content-section section">
                <div class="container">
                    <div class="entry-content">
                        <?php the_content(); ?>
                    </div>
                </div>
            </section>
            <?php
        endif;
    endwhile;
    ?>

</main>

<?php
get_footer();
