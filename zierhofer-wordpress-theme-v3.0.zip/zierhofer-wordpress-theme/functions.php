<?php
/**
 * Zierhofer Installateur Theme Functions
 * 
 * @package Zierhofer
 * @author Black10998
 * @version 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Theme version
define('ZIERHOFER_VERSION', '3.0.0');

/**
 * Theme Setup
 */
function zierhofer_setup() {
    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');
    
    // Let WordPress manage the document title
    add_theme_support('title-tag');
    
    // Enable support for Post Thumbnails
    add_theme_support('post-thumbnails');
    
    // Set default thumbnail size
    set_post_thumbnail_size(1200, 630, true);
    
    // Add custom image sizes
    add_image_size('zierhofer-hero', 1920, 1080, true);
    add_image_size('zierhofer-service', 500, 500, true);
    add_image_size('zierhofer-logo', 200, 200, false);
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'zierhofer'),
        'footer' => __('Footer Menu', 'zierhofer'),
    ));
    
    // Switch default core markup to output valid HTML5
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
    
    // Add theme support for selective refresh for widgets
    add_theme_support('customize-selective-refresh-widgets');
    
    // Add support for custom logo
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // Add support for editor styles
    add_theme_support('editor-styles');
    
    // Load translations
    load_theme_textdomain('zierhofer', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'zierhofer_setup');

/**
 * Set the content width in pixels
 */
function zierhofer_content_width() {
    $GLOBALS['content_width'] = apply_filters('zierhofer_content_width', 1200);
}
add_action('after_setup_theme', 'zierhofer_content_width', 0);

/**
 * Enqueue scripts and styles
 */
function zierhofer_scripts() {
    // Main stylesheet
    wp_enqueue_style('zierhofer-style', get_stylesheet_uri(), array(), ZIERHOFER_VERSION);
    
    // Custom fonts
    wp_enqueue_style('zierhofer-fonts', get_template_directory_uri() . '/assets/css/fonts.css', array(), ZIERHOFER_VERSION);
    
    // Main JavaScript
    wp_enqueue_script('zierhofer-main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), ZIERHOFER_VERSION, true);
    
    // Navigation script
    wp_enqueue_script('zierhofer-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array('jquery'), ZIERHOFER_VERSION, true);
    
    // Comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
    
    // Localize script for AJAX
    wp_localize_script('zierhofer-main', 'zierhoferData', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('zierhofer-nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'zierhofer_scripts');

/**
 * Register widget areas
 */
function zierhofer_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Widget Area 1', 'zierhofer'),
        'id'            => 'footer-1',
        'description'   => __('Add widgets here to appear in your footer.', 'zierhofer'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Widget Area 2', 'zierhofer'),
        'id'            => 'footer-2',
        'description'   => __('Add widgets here to appear in your footer.', 'zierhofer'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Widget Area 3', 'zierhofer'),
        'id'            => 'footer-3',
        'description'   => __('Add widgets here to appear in your footer.', 'zierhofer'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'zierhofer_widgets_init');

/**
 * Customizer Settings
 */
function zierhofer_customize_register($wp_customize) {
    // Company Information Section
    $wp_customize->add_section('zierhofer_company_info', array(
        'title'    => __('Company Information', 'zierhofer'),
        'priority' => 30,
    ));
    
    // Company Name
    $wp_customize->add_setting('zierhofer_company_name', array(
        'default'           => 'Sana Tec',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_company_name', array(
        'label'    => __('Company Name', 'zierhofer'),
        'section'  => 'zierhofer_company_info',
        'type'     => 'text',
    ));
    
    // Company Tagline
    $wp_customize->add_setting('zierhofer_company_tagline', array(
        'default'           => 'Innungs- und Meisterfachbetrieb in Berlin',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_company_tagline', array(
        'label'    => __('Company Tagline', 'zierhofer'),
        'section'  => 'zierhofer_company_info',
        'type'     => 'text',
    ));
    
    // Phone Number
    $wp_customize->add_setting('zierhofer_phone', array(
        'default'           => '+49 30 12345678',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_phone', array(
        'label'    => __('Phone Number', 'zierhofer'),
        'section'  => 'zierhofer_company_info',
        'type'     => 'text',
    ));
    
    // Emergency Phone
    $wp_customize->add_setting('zierhofer_emergency_phone', array(
        'default'           => '+49 30 24/7 Notdienst',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_emergency_phone', array(
        'label'    => __('Emergency Phone (24h)', 'zierhofer'),
        'section'  => 'zierhofer_company_info',
        'type'     => 'text',
    ));
    
    // Email
    $wp_customize->add_setting('zierhofer_email', array(
        'default'           => 'info@sana-tec.de',
        'sanitize_callback' => 'sanitize_email',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_email', array(
        'label'    => __('Email Address', 'zierhofer'),
        'section'  => 'zierhofer_company_info',
        'type'     => 'email',
    ));
    
    // Address
    $wp_customize->add_setting('zierhofer_address', array(
        'default'           => 'Musterstraße 123, 12345 Berlin',
        'sanitize_callback' => 'sanitize_textarea_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_address', array(
        'label'    => __('Address', 'zierhofer'),
        'section'  => 'zierhofer_company_info',
        'type'     => 'textarea',
    ));
    
    // Opening Hours
    $wp_customize->add_setting('zierhofer_opening_hours', array(
        'default'           => 'Mo-Fr: 08:00 - 17:00 Uhr',
        'sanitize_callback' => 'sanitize_textarea_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_opening_hours', array(
        'label'    => __('Opening Hours', 'zierhofer'),
        'section'  => 'zierhofer_company_info',
        'type'     => 'textarea',
    ));
    
    // Hero Section
    $wp_customize->add_section('zierhofer_hero', array(
        'title'    => __('Hero Section', 'zierhofer'),
        'priority' => 31,
    ));
    
    // Hero Title
    $wp_customize->add_setting('zierhofer_hero_title', array(
        'default'           => 'Gas-, Wasser- und Heizungsinstallateur',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_hero_title', array(
        'label'    => __('Hero Title', 'zierhofer'),
        'section'  => 'zierhofer_hero',
        'type'     => 'text',
    ));
    
    // Hero Subtitle
    $wp_customize->add_setting('zierhofer_hero_subtitle', array(
        'default'           => 'Innungs- und Meisterfachbetrieb in Berlin',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_hero_subtitle', array(
        'label'    => __('Hero Subtitle', 'zierhofer'),
        'section'  => 'zierhofer_hero',
        'type'     => 'text',
    ));
    
    // Hero Description
    $wp_customize->add_setting('zierhofer_hero_description', array(
        'default'           => 'Sana Tec ist ein Berliner Meisterbetrieb, spezialisiert auf Gas, Wasser und Heizung.',
        'sanitize_callback' => 'sanitize_textarea_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_hero_description', array(
        'label'    => __('Hero Description', 'zierhofer'),
        'section'  => 'zierhofer_hero',
        'type'     => 'textarea',
    ));
    
    // About Section
    $wp_customize->add_section('zierhofer_about', array(
        'title'    => __('About Section', 'zierhofer'),
        'priority' => 32,
    ));
    
    // About Title
    $wp_customize->add_setting('zierhofer_about_title', array(
        'default'           => 'Über uns',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_about_title', array(
        'label'    => __('About Title', 'zierhofer'),
        'section'  => 'zierhofer_about',
        'type'     => 'text',
    ));
    
    // About Content
    $wp_customize->add_setting('zierhofer_about_content', array(
        'default'           => 'Sana Tec ist ein Berliner Meisterbetrieb, spezialisiert auf Gas, Wasser und Heizung. Als mittelständisches Unternehmen bieten wir qualitativ hochwertige Installationen, Wartungen und Reparaturen an.',
        'sanitize_callback' => 'wp_kses_post',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_about_content', array(
        'label'    => __('About Content', 'zierhofer'),
        'section'  => 'zierhofer_about',
        'type'     => 'textarea',
    ));
    
    // Footer Section
    $wp_customize->add_section('zierhofer_footer', array(
        'title'    => __('Footer Settings', 'zierhofer'),
        'priority' => 33,
    ));
    
    // Footer Copyright
    $wp_customize->add_setting('zierhofer_footer_copyright', array(
        'default'           => '© 2025 Sana Tec. Alle Rechte vorbehalten.',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_footer_copyright', array(
        'label'    => __('Footer Copyright Text', 'zierhofer'),
        'section'  => 'zierhofer_footer',
        'type'     => 'text',
    ));
    
    // Developer Credit
    $wp_customize->add_setting('zierhofer_developer_credit', array(
        'default'           => 'Developed by Black10998',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('zierhofer_developer_credit', array(
        'label'    => __('Developer Credit', 'zierhofer'),
        'section'  => 'zierhofer_footer',
        'type'     => 'text',
    ));
}
add_action('customize_register', 'zierhofer_customize_register');

/**
 * Custom template tags
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions
 */
require get_template_directory() . '/inc/custom-functions.php';

/**
 * Customizer additions
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Remove external links from content
 */
function zierhofer_remove_external_links($content) {
    $site_url = home_url();
    $content = preg_replace_callback(
        '/<a\s+(?:[^>]*?\s+)?href=(["\'])(.*?)\1/i',
        function($matches) use ($site_url) {
            $url = $matches[2];
            // Allow internal links, anchors, and relative URLs
            if (strpos($url, '#') === 0 || strpos($url, '/') === 0 || strpos($url, $site_url) === 0) {
                return $matches[0];
            }
            // Remove external links (starting with http/https but not site URL)
            if (strpos($url, 'http') === 0) {
                return '<span class="external-link-removed"';
            }
            return $matches[0];
        },
        $content
    );
    return $content;
}
add_filter('the_content', 'zierhofer_remove_external_links', 999);

/**
 * Remove external links from navigation menus
 */
function zierhofer_remove_external_nav_links($items, $args) {
    $site_url = home_url();
    foreach ($items as $key => $item) {
        $url = $item->url;
        // Remove external links from menu
        if (strpos($url, 'http') === 0 && strpos($url, $site_url) === false) {
            unset($items[$key]);
        }
    }
    return $items;
}
add_filter('wp_nav_menu_objects', 'zierhofer_remove_external_nav_links', 10, 2);

/**
 * Add SVG support
 */
function zierhofer_mime_types($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'zierhofer_mime_types');

/**
 * Custom excerpt length
 */
function zierhofer_excerpt_length($length) {
    return 30;
}
add_filter('excerpt_length', 'zierhofer_excerpt_length');

/**
 * Custom excerpt more
 */
function zierhofer_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'zierhofer_excerpt_more');

/**
 * Add body classes
 */
function zierhofer_body_classes($classes) {
    if (!is_singular()) {
        $classes[] = 'hfeed';
    }
    
    if (is_front_page()) {
        $classes[] = 'front-page';
    }
    
    return $classes;
}
add_filter('body_class', 'zierhofer_body_classes');

/**
 * Disable WordPress emoji
 */
function zierhofer_disable_emojis() {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
}
add_action('init', 'zierhofer_disable_emojis');

/**
 * Optimize WordPress
 */
function zierhofer_optimize_wordpress() {
    // Remove WordPress version
    remove_action('wp_head', 'wp_generator');
    
    // Remove RSD link
    remove_action('wp_head', 'rsd_link');
    
    // Remove wlwmanifest link
    remove_action('wp_head', 'wlwmanifest_link');
    
    // Remove shortlink
    remove_action('wp_head', 'wp_shortlink_wp_head');
    
    // Remove REST API link
    remove_action('wp_head', 'rest_output_link_wp_head');
    
    // Remove oEmbed discovery links
    remove_action('wp_head', 'wp_oembed_add_discovery_links');
}
add_action('init', 'zierhofer_optimize_wordpress');
