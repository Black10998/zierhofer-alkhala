    </div><!-- #content -->

    <footer id="colophon" class="site-footer">
        <div class="container">
            <div class="footer-content">
                <?php if (is_active_sidebar('footer-1')) : ?>
                    <div class="footer-column">
                        <?php dynamic_sidebar('footer-1'); ?>
                    </div>
                <?php endif; ?>

                <?php if (is_active_sidebar('footer-2')) : ?>
                    <div class="footer-column">
                        <?php dynamic_sidebar('footer-2'); ?>
                    </div>
                <?php endif; ?>

                <?php if (is_active_sidebar('footer-3')) : ?>
                    <div class="footer-column">
                        <?php dynamic_sidebar('footer-3'); ?>
                    </div>
                <?php endif; ?>

                <?php if (!is_active_sidebar('footer-1') && !is_active_sidebar('footer-2') && !is_active_sidebar('footer-3')) : ?>
                    <div class="footer-column">
                        <div class="footer-widget">
                            <h3><?php echo esc_html(get_theme_mod('zierhofer_company_name', 'Sana Tec')); ?></h3>
                            <p><?php echo esc_html(get_theme_mod('zierhofer_company_tagline', 'Innungs- und Meisterfachbetrieb in Berlin')); ?></p>
                        </div>
                    </div>

                    <div class="footer-column">
                        <div class="footer-widget">
                            <h3><?php esc_html_e('Kontakt', 'zierhofer'); ?></h3>
                            <ul>
                                <li><strong><?php esc_html_e('Telefon:', 'zierhofer'); ?></strong> <?php echo esc_html(get_theme_mod('zierhofer_phone', '+49 30 12345678')); ?></li>
                                <li><strong><?php esc_html_e('Notdienst:', 'zierhofer'); ?></strong> <?php echo esc_html(get_theme_mod('zierhofer_emergency_phone', '+49 30 24/7')); ?></li>
                                <li><strong><?php esc_html_e('E-Mail:', 'zierhofer'); ?></strong> <?php echo esc_html(get_theme_mod('zierhofer_email', 'info@sana-tec.de')); ?></li>
                            </ul>
                        </div>
                    </div>

                    <div class="footer-column">
                        <div class="footer-widget">
                            <h3><?php esc_html_e('Adresse', 'zierhofer'); ?></h3>
                            <p><?php echo nl2br(esc_html(get_theme_mod('zierhofer_address', 'Musterstraße 123, 12345 Berlin'))); ?></p>
                            <p><strong><?php esc_html_e('Öffnungszeiten:', 'zierhofer'); ?></strong><br>
                            <?php echo nl2br(esc_html(get_theme_mod('zierhofer_opening_hours', 'Mo-Fr: 08:00 - 17:00 Uhr'))); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="footer-bottom">
                <p><?php echo esc_html(get_theme_mod('zierhofer_footer_copyright', '© 2025 Sana Tec. Alle Rechte vorbehalten.')); ?></p>
                <p><?php echo esc_html(get_theme_mod('zierhofer_developer_credit', 'Developed by Black10998')); ?></p>
                <p>
                    <a href="<?php echo esc_url(home_url('/impressum')); ?>"><?php esc_html_e('Impressum', 'zierhofer'); ?></a> | 
                    <a href="<?php echo esc_url(home_url('/datenschutz')); ?>"><?php esc_html_e('Datenschutz', 'zierhofer'); ?></a>
                </p>
            </div>
        </div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
