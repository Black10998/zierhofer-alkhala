<?php
/**
 * Front Page Template
 * 
 * This template displays the homepage with exact 1:1 design from the original site
 *
 * @package Zierhofer
 */

get_header();
?>

<main id="primary" class="site-main front-page">
    
    <!-- Hero Section -->
    <section class="hero-section section">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">
                    <?php echo esc_html(get_theme_mod('zierhofer_hero_title', 'Gas-, Wasser- und Heizungsinstallateur')); ?>
                </h1>
                <p class="hero-subtitle">
                    <?php echo esc_html(get_theme_mod('zierhofer_hero_subtitle', 'Innungs- und Meisterfachbetrieb in Berlin')); ?>
                </p>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="ueber-uns" class="about-section section">
        <div class="container">
            <div class="row">
                <div class="col col-half">
                    <div class="section-title underline-3">
                        <h2>
                            <span class="main-head"><?php echo esc_html(get_theme_mod('zierhofer_about_title', 'Über uns')); ?></span>
                            <span class="sub-head"><?php echo esc_html(get_theme_mod('zierhofer_company_tagline', 'Innungs- und Meisterfachbetrieb in Berlin')); ?></span>
                        </h2>
                    </div>
                    <div class="content-block">
                        <p><?php echo wp_kses_post(get_theme_mod('zierhofer_about_content', 'Sana Tec ist ein Berliner Meisterbetrieb, spezialisiert auf Gas, Wasser und Heizung. Als mittelständisches Unternehmen bieten wir qualitativ hochwertige Installationen, Wartungen und Reparaturen an. Wir betreuen eine Vielzahl an Kunden, darunter auch große Hausverwaltungen. Neben unserer hohen Fachkompetenz legen wir großen Wert auf die Ausbildung neuer Fachkräfte. Unsere hohe Kundenzufriedenheit und die enge Zusammenarbeit mit Partnern machen uns zu einem vertrauenswürdigen Dienstleister im Bereich der Sanitär- und Heizungstechnik.')); ?></p>
                    </div>
                </div>
                <div class="col col-half">
                    <div class="image-circle">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2021/08/Logo-6.png'); ?>" alt="<?php bloginfo('name'); ?>">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section - Leistungen -->
    <section id="leistungen" class="services-section section">
        <div class="container">
            <div class="section-title underline-2 text-center">
                <h2>
                    <span class="main-head">Unsere Leistungen</span>
                    <span class="sub-head">Professionelle Installationen und Wartungen</span>
                </h2>
            </div>
            
            <div class="services-grid">
                <div class="service-item">
                    <div class="image-circle">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/01/sanatec-gasinstallateur-500x500.png'); ?>" alt="Gasinstallateur">
                    </div>
                    <h3>Gasinstallateur</h3>
                    <p>Professionelle Gasinstallationen und Wartungen für Ihre Sicherheit.</p>
                    <a href="<?php echo esc_url(home_url('/leistungen#gas')); ?>" class="btn">Mehr erfahren</a>
                </div>

                <div class="service-item">
                    <div class="image-circle">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/01/sanatec-sanitaerinstallateur-500x500.png'); ?>" alt="Sanitärinstallateur">
                    </div>
                    <h3>Sanitärinstallateur</h3>
                    <p>Moderne Sanitäranlagen für Ihr Zuhause und Gewerbe.</p>
                    <a href="<?php echo esc_url(home_url('/leistungen#sanitaer')); ?>" class="btn">Mehr erfahren</a>
                </div>

                <div class="service-item">
                    <div class="image-circle">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/01/sanatec-heizungstechnik-500x500.png'); ?>" alt="Heizungstechnik">
                    </div>
                    <h3>Heizungstechnik</h3>
                    <p>Effiziente Heizungssysteme für optimalen Komfort.</p>
                    <a href="<?php echo esc_url(home_url('/leistungen#heizung')); ?>" class="btn">Mehr erfahren</a>
                </div>

                <div class="service-item">
                    <div class="image-circle">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/01/sanatec-sanierung-500x500.png'); ?>" alt="Sanierung">
                    </div>
                    <h3>Sanierung</h3>
                    <p>Fachgerechte Sanierung von Altbauten und Bestandsimmobilien.</p>
                    <a href="<?php echo esc_url(home_url('/leistungen#sanierung')); ?>" class="btn">Mehr erfahren</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Sustainability Section - Nachhaltigkeit -->
    <section id="nachhaltigkeit" class="sustainability-section section">
        <div class="container">
            <div class="row">
                <div class="col col-half">
                    <div class="section-title underline-3">
                        <h2>
                            <span class="main-head">Nachhaltigkeit</span>
                            <span class="sub-head">wird bei uns großgeschrieben</span>
                        </h2>
                    </div>
                    <div class="content-block">
                        <p><strong>Wir sind zukunftsorientiert und setzen auf erneuerbare Energien!</strong></p>
                        <p>Wir bauen die Welt für unsere Kinder und dabei spielen erneuerbare Energien eine entscheidende Rolle. Wenn Sie einen zuverlässigen Partner für die Modernisierung Ihrer Heizanlage sind, wenden Sie sich an uns.</p>
                        <a href="<?php echo esc_url(home_url('/leistungen')); ?>" class="btn">Leistungen</a>
                    </div>
                </div>
                <div class="col col-half">
                    <div class="image-circle">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/01/sanatec-waermepumpe-500x500.png'); ?>" alt="Wärmepumpe">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Emergency Service Section - Notdienst -->
    <section id="notdienst" class="emergency-section section">
        <div class="container">
            <div class="icon-module">
                <svg class="icon-bolt" width="64" height="64" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M13 2L3 14h8l-1 8 10-12h-8l1-8z"/>
                </svg>
            </div>
            <div class="section-title underline-2 text-center">
                <h2>
                    <span class="main-head">24 Std. Notdienst</span>
                </h2>
            </div>
            <div class="content-block text-center">
                <p><strong>Für Gas-, Heizung- und Sanitäranlagen in Berlin.</strong></p>
                <a href="<?php echo esc_url(home_url('/notdienst')); ?>" class="btn">Notdienst</a>
            </div>
        </div>
    </section>

    <!-- Training Section - Ausbildung -->
    <section id="ausbildung" class="training-section section">
        <div class="container">
            <div class="row">
                <div class="col col-half">
                    <div class="section-title underline-3">
                        <h2>
                            <span class="main-head">Ausbildung</span>
                            <span class="sub-head">als Gas-, Wasser- und Heizungsinstallateur</span>
                        </h2>
                    </div>
                    <div class="content-block">
                        <p>Was wäre die Menschheit ohne das Handwerk? Unser Ziel ist es, Jugendliche für den Handwerksberuf zu begeistern und ihnen eine Perspektive für die Zukunft zu bieten. Wir suchen ständig engagierte Anlagenmechaniker und Auszubildende – bewerben Sie sich jetzt und unterstützen Sie unser Team!</p>
                        <a href="<?php echo esc_url(home_url('/karriere')); ?>" class="btn">Karriere</a>
                    </div>
                </div>
                <div class="col col-half">
                    <div class="image-circle">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/01/sanatec-ausbildung-500x500.png'); ?>" alt="Ausbildung">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Customer Types Section -->
    <section class="customer-types-section section">
        <div class="container">
            <div class="row">
                <div class="col col-half">
                    <div class="image-circle">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/01/sanatec-privatkunden-200x200.png'); ?>" alt="Privatkunden">
                    </div>
                    <div class="section-title underline-1">
                        <h2>
                            <span class="main-head">Privatkunden</span>
                        </h2>
                    </div>
                </div>
                <div class="col col-half">
                    <div class="image-circle">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/01/sanatec-gewerbekunden-200x200.png'); ?>" alt="Gewerbekunden">
                    </div>
                    <div class="section-title underline-1">
                        <h2>
                            <span class="main-head">Gewerbekunden</span>
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Memberships Section - Mitgliedschaften -->
    <section class="memberships-section section">
        <div class="container">
            <div class="section-title underline-1">
                <h2>
                    <span class="main-head">Mitgliedschaften</span>
                </h2>
            </div>
            
            <div class="memberships-grid">
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/1-IHK.jpg'); ?>" alt="IHK">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/2-SHK.png'); ?>" alt="SHK">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/3-handwerkskammer.png'); ?>" alt="Handwerkskammer">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/4-creditreform.webp'); ?>" alt="Creditreform">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/5-bg-bau.png'); ?>" alt="BG Bau">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/6-Berliner-Wasserbetriebe.png'); ?>" alt="Berliner Wasserbetriebe">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/7-Netzgesellschaft-Berlin-Brandenburg.jpg'); ?>" alt="Netzgesellschaft Berlin-Brandenburg">
                </div>
            </div>
        </div>
    </section>

    <!-- Partners Section - Partner -->
    <section class="partners-section section">
        <div class="container">
            <div class="section-title underline-1 text-center">
                <h2>
                    <span class="main-head">Unsere Partner</span>
                </h2>
            </div>
            
            <div class="memberships-grid">
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/1-logo-vaillant.png'); ?>" alt="Vaillant">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/2-logo-bosch.webp'); ?>" alt="Bosch">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/3-logo-partner-buderus.webp'); ?>" alt="Buderus">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/4-weishaupt-logo-scaled.jpg'); ?>" alt="Weishaupt">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/5-geberit.webp'); ?>" alt="Geberit">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/6-Viessmann-logo.png'); ?>" alt="Viessmann">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/7-Wolf_Logo.jpg'); ?>" alt="Wolf">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/8-Junkers.webp'); ?>" alt="Junkers">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/10-Ariston-Logo.jpg'); ?>" alt="Ariston">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/10-Hansgrohe-Logo.png'); ?>" alt="Hansgrohe">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/11-logo-grohe.webp'); ?>" alt="Grohe">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/12-logo-wilo.jpg'); ?>" alt="Wilo">
                </div>
                <div class="membership-item">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/13-clage-logo.png'); ?>" alt="Clage">
                </div>
            </div>
        </div>
    </section>

</main>

<?php
get_footer();
