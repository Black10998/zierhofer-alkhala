<?php
/**
 * Custom functions for this theme
 *
 * @package Zierhofer
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get company information
 */
function zierhofer_get_company_info($key, $default = '') {
    return get_theme_mod('zierhofer_' . $key, $default);
}

/**
 * Display company phone number
 */
function zierhofer_display_phone() {
    $phone = zierhofer_get_company_info('phone', '+49 30 12345678');
    echo '<a href="tel:' . esc_attr(str_replace(' ', '', $phone)) . '">' . esc_html($phone) . '</a>';
}

/**
 * Display emergency phone number
 */
function zierhofer_display_emergency_phone() {
    $phone = zierhofer_get_company_info('emergency_phone', '+49 30 24/7');
    echo '<a href="tel:' . esc_attr(str_replace(' ', '', $phone)) . '">' . esc_html($phone) . '</a>';
}

/**
 * Display company email
 */
function zierhofer_display_email() {
    $email = zierhofer_get_company_info('email', 'info@sana-tec.de');
    echo '<a href="mailto:' . esc_attr($email) . '">' . esc_html($email) . '</a>';
}

/**
 * Display company address
 */
function zierhofer_display_address() {
    $address = zierhofer_get_company_info('address', 'Musterstraße 123, 12345 Berlin');
    echo nl2br(esc_html($address));
}

/**
 * Display opening hours
 */
function zierhofer_display_opening_hours() {
    $hours = zierhofer_get_company_info('opening_hours', 'Mo-Fr: 08:00 - 17:00 Uhr');
    echo nl2br(esc_html($hours));
}

/**
 * Check if external link
 */
function zierhofer_is_external_link($url) {
    $site_url = home_url();
    return (strpos($url, $site_url) === false && strpos($url, 'http') === 0);
}

/**
 * Sanitize external links
 */
function zierhofer_sanitize_link($url) {
    if (zierhofer_is_external_link($url)) {
        return '#';
    }
    return $url;
}

/**
 * Get service items
 */
function zierhofer_get_services() {
    return array(
        array(
            'title' => 'Gasinstallateur',
            'description' => 'Professionelle Gasinstallationen und Wartungen für Ihre Sicherheit.',
            'image' => 'sanatec-gasinstallateur-500x500.png',
            'link' => home_url('/leistungen#gas'),
        ),
        array(
            'title' => 'Sanitärinstallateur',
            'description' => 'Moderne Sanitäranlagen für Ihr Zuhause und Gewerbe.',
            'image' => 'sanatec-sanitaerinstallateur-500x500.png',
            'link' => home_url('/leistungen#sanitaer'),
        ),
        array(
            'title' => 'Heizungstechnik',
            'description' => 'Effiziente Heizungssysteme für optimalen Komfort.',
            'image' => 'sanatec-heizungstechnik-500x500.png',
            'link' => home_url('/leistungen#heizung'),
        ),
        array(
            'title' => 'Sanierung',
            'description' => 'Fachgerechte Sanierung von Altbauten und Bestandsimmobilien.',
            'image' => 'sanatec-sanierung-500x500.png',
            'link' => home_url('/leistungen#sanierung'),
        ),
    );
}

/**
 * Display service grid
 */
function zierhofer_display_services() {
    $services = zierhofer_get_services();
    
    echo '<div class="services-grid">';
    foreach ($services as $service) {
        ?>
        <div class="service-item">
            <div class="image-circle">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/01/' . $service['image']); ?>" alt="<?php echo esc_attr($service['title']); ?>">
            </div>
            <h3><?php echo esc_html($service['title']); ?></h3>
            <p><?php echo esc_html($service['description']); ?></p>
            <a href="<?php echo esc_url($service['link']); ?>" class="btn"><?php esc_html_e('Mehr erfahren', 'zierhofer'); ?></a>
        </div>
        <?php
    }
    echo '</div>';
}

/**
 * Get membership logos
 */
function zierhofer_get_memberships() {
    return array(
        '1-IHK.jpg',
        '2-SHK.png',
        '3-handwerkskammer.png',
        '4-creditreform.webp',
        '5-bg-bau.png',
        '6-Berliner-Wasserbetriebe.png',
        '7-Netzgesellschaft-Berlin-Brandenburg.jpg',
    );
}

/**
 * Get partner logos
 */
function zierhofer_get_partners() {
    return array(
        '1-logo-vaillant.png',
        '2-logo-bosch.webp',
        '3-logo-partner-buderus.webp',
        '4-weishaupt-logo-scaled.jpg',
        '5-geberit.webp',
        '6-Viessmann-logo.png',
        '7-Wolf_Logo.jpg',
        '8-Junkers.webp',
        '10-Ariston-Logo.jpg',
        '10-Hansgrohe-Logo.png',
        '11-logo-grohe.webp',
        '12-logo-wilo.jpg',
        '13-clage-logo.png',
    );
}

/**
 * Display membership logos
 */
function zierhofer_display_memberships() {
    $memberships = zierhofer_get_memberships();
    
    echo '<div class="memberships-grid">';
    foreach ($memberships as $logo) {
        $alt = pathinfo($logo, PATHINFO_FILENAME);
        ?>
        <div class="membership-item">
            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/' . $logo); ?>" alt="<?php echo esc_attr($alt); ?>">
        </div>
        <?php
    }
    echo '</div>';
}

/**
 * Display partner logos
 */
function zierhofer_display_partners() {
    $partners = zierhofer_get_partners();
    
    echo '<div class="memberships-grid">';
    foreach ($partners as $logo) {
        $alt = pathinfo($logo, PATHINFO_FILENAME);
        ?>
        <div class="membership-item">
            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/2025/03/' . $logo); ?>" alt="<?php echo esc_attr($alt); ?>">
        </div>
        <?php
    }
    echo '</div>';
}
