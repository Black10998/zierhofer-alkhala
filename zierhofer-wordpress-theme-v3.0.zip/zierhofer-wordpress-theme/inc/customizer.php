<?php
/**
 * Customizer additions
 *
 * @package Zierhofer
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously
 */
function zierhofer_customize_preview_js() {
    wp_enqueue_script('zierhofer-customizer', get_template_directory_uri() . '/assets/js/customizer.js', array('customize-preview'), ZIERHOFER_VERSION, true);
}
add_action('customize_preview_init', 'zierhofer_customize_preview_js');
