<?php
/**
 * Template Name: Notdienst
 * Template for the emergency service page
 *
 * @package Zierhofer
 */

get_header();
?>

<main id="primary" class="site-main page-notdienst">
    
    <section class="emergency-section section">
        <div class="container">
            <div class="icon-module">
                <svg class="icon-bolt" width="96" height="96" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M13 2L3 14h8l-1 8 10-12h-8l1-8z"/>
                </svg>
            </div>
            <div class="hero-content text-center">
                <h1 class="hero-title">24 Stunden Notdienst</h1>
                <p class="hero-subtitle">Für Gas-, Heizung- und Sanitäranlagen in Berlin</p>
                <div class="emergency-phone">
                    <h2><?php zierhofer_display_emergency_phone(); ?></h2>
                </div>
            </div>
        </div>
    </section>

    <section class="emergency-info-section section">
        <div class="container">
            <div class="section-title underline-2 text-center">
                <h2>
                    <span class="main-head">Schnelle Hilfe im Notfall</span>
                    <span class="sub-head">Wir sind rund um die Uhr für Sie da</span>
                </h2>
            </div>

            <div class="content-block">
                <p class="text-center">Bei einem Notfall zählt jede Minute. Unser erfahrenes Team steht Ihnen 24 Stunden am Tag, 7 Tage die Woche zur Verfügung, um schnell und professionell zu helfen.</p>
            </div>

            <div class="services-grid">
                <div class="service-item">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M13 2L3 14h8l-1 8 10-12h-8l1-8z"/>
                    </svg>
                    <h3>Gasnotdienst</h3>
                    <p>Sofortige Hilfe bei Gasgeruch, Gaslecks und defekten Gasthermen</p>
                </div>

                <div class="service-item">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M13 2L3 14h8l-1 8 10-12h-8l1-8z"/>
                    </svg>
                    <h3>Heizungsnotdienst</h3>
                    <p>Schnelle Reparatur bei Heizungsausfall, besonders in der kalten Jahreszeit</p>
                </div>

                <div class="service-item">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M13 2L3 14h8l-1 8 10-12h-8l1-8z"/>
                    </svg>
                    <h3>Sanitärnotdienst</h3>
                    <p>Soforthilfe bei Rohrbruch, verstopften Leitungen und Wasserschäden</p>
                </div>

                <div class="service-item">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M13 2L3 14h8l-1 8 10-12h-8l1-8z"/>
                    </svg>
                    <h3>Wasserschaden</h3>
                    <p>Schnelle Schadensbegrenzung und Reparatur bei Wasserschäden</p>
                </div>
            </div>
        </div>
    </section>

    <section class="emergency-cases-section section">
        <div class="container">
            <div class="section-title underline-2 text-center">
                <h2>
                    <span class="main-head">Wann sollten Sie uns rufen?</span>
                    <span class="sub-head">Typische Notfälle</span>
                </h2>
            </div>

            <div class="row">
                <div class="col col-half">
                    <h3>Gas-Notfälle</h3>
                    <ul class="emergency-list">
                        <li>Gasgeruch in der Wohnung oder im Haus</li>
                        <li>Defekte Gastherme</li>
                        <li>Gasleck</li>
                        <li>Ausfall der Gasversorgung</li>
                        <li>CO-Melder schlägt Alarm</li>
                    </ul>

                    <h3>Heizungs-Notfälle</h3>
                    <ul class="emergency-list">
                        <li>Kompletter Heizungsausfall im Winter</li>
                        <li>Keine Warmwasserversorgung</li>
                        <li>Heizung macht ungewöhnliche Geräusche</li>
                        <li>Wasserdruck zu niedrig</li>
                        <li>Heizkörper bleiben kalt</li>
                    </ul>
                </div>

                <div class="col col-half">
                    <h3>Sanitär-Notfälle</h3>
                    <ul class="emergency-list">
                        <li>Rohrbruch mit austretendem Wasser</li>
                        <li>Verstopfte Toilette oder Abfluss</li>
                        <li>Defekte Wasserleitungen</li>
                        <li>Überlaufende Toilette</li>
                        <li>Tropfende oder undichte Armaturen</li>
                    </ul>

                    <h3>Wasserschäden</h3>
                    <ul class="emergency-list">
                        <li>Akuter Wasserschaden</li>
                        <li>Überschwemmung</li>
                        <li>Leckage in Wänden oder Decken</li>
                        <li>Defekte Waschmaschinenanschlüsse</li>
                        <li>Rückstau aus der Kanalisation</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="emergency-process-section section">
        <div class="container">
            <div class="section-title underline-2 text-center">
                <h2>
                    <span class="main-head">So läuft es ab</span>
                    <span class="sub-head">Unser Notdienst-Prozess</span>
                </h2>
            </div>

            <div class="process-steps">
                <div class="process-step">
                    <div class="step-number">1</div>
                    <h3>Anruf</h3>
                    <p>Sie rufen unsere Notdienst-Hotline an und schildern das Problem</p>
                </div>

                <div class="process-step">
                    <div class="step-number">2</div>
                    <h3>Sofortmaßnahmen</h3>
                    <p>Wir geben Ihnen telefonisch erste Anweisungen zur Schadensbegrenzung</p>
                </div>

                <div class="process-step">
                    <div class="step-number">3</div>
                    <h3>Anfahrt</h3>
                    <p>Unser Notdienst-Team macht sich umgehend auf den Weg zu Ihnen</p>
                </div>

                <div class="process-step">
                    <div class="step-number">4</div>
                    <h3>Diagnose</h3>
                    <p>Vor Ort analysieren wir das Problem und erstellen einen Lösungsplan</p>
                </div>

                <div class="process-step">
                    <div class="step-number">5</div>
                    <h3>Reparatur</h3>
                    <p>Wir führen die notwendigen Reparaturen schnell und fachgerecht durch</p>
                </div>

                <div class="process-step">
                    <div class="step-number">6</div>
                    <h3>Abschluss</h3>
                    <p>Nach erfolgreicher Reparatur erhalten Sie eine transparente Rechnung</p>
                </div>
            </div>
        </div>
    </section>

    <section class="emergency-tips-section section">
        <div class="container">
            <div class="section-title underline-2 text-center">
                <h2>
                    <span class="main-head">Wichtige Tipps</span>
                    <span class="sub-head">Was Sie im Notfall tun sollten</span>
                </h2>
            </div>

            <div class="tips-grid">
                <div class="tip-item">
                    <h3>Bei Gasgeruch</h3>
                    <ul>
                        <li>Keine elektrischen Geräte betätigen</li>
                        <li>Nicht rauchen oder offenes Feuer verwenden</li>
                        <li>Fenster öffnen</li>
                        <li>Gaszufuhr abstellen</li>
                        <li>Gebäude verlassen</li>
                        <li>Notdienst rufen</li>
                    </ul>
                </div>

                <div class="tip-item">
                    <h3>Bei Rohrbruch</h3>
                    <ul>
                        <li>Hauptwasserhahn sofort schließen</li>
                        <li>Strom in betroffenen Bereichen abschalten</li>
                        <li>Wasser auffangen</li>
                        <li>Möbel und Wertgegenstände in Sicherheit bringen</li>
                        <li>Notdienst kontaktieren</li>
                    </ul>
                </div>

                <div class="tip-item">
                    <h3>Bei Heizungsausfall</h3>
                    <ul>
                        <li>Thermostat überprüfen</li>
                        <li>Wasserdruck kontrollieren</li>
                        <li>Heizkörper entlüften</li>
                        <li>Sicherungen prüfen</li>
                        <li>Bei anhaltenden Problemen Notdienst rufen</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="emergency-contact-section section emergency-section">
        <div class="container">
            <div class="section-title underline-2 text-center">
                <h2>
                    <span class="main-head">Jetzt Notdienst kontaktieren</span>
                </h2>
            </div>

            <div class="content-block text-center">
                <p><strong>24 Stunden erreichbar - 7 Tage die Woche</strong></p>
                <div class="emergency-phone-large">
                    <h2><?php zierhofer_display_emergency_phone(); ?></h2>
                </div>
                <p>Oder schreiben Sie uns eine E-Mail:</p>
                <p><?php zierhofer_display_email(); ?></p>
            </div>
        </div>
    </section>

    <?php
    while (have_posts()) :
        the_post();
        if (get_the_content()) :
            ?>
            <section class="page-content-section section">
                <div class="container">
                    <div class="entry-content">
                        <?php the_content(); ?>
                    </div>
                </div>
            </section>
            <?php
        endif;
    endwhile;
    ?>

</main>

<?php
get_footer();
