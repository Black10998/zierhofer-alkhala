# Zierhofer Installateur WordPress Theme

**Version:** 3.0.0  
**Author:** Black10998  
**License:** GPL v2 or later  
**Source Repository:** [https://github.com/Black10998/zierhofer-alkhala](https://github.com/Black10998/zierhofer-alkhala)

## Description

Professional WordPress theme for Sana Tec - Gas, Wasser und Heizung Installateur in Berlin. This theme is an exact 1:1 conversion from the original static HTML website, maintaining complete visual fidelity while adding WordPress content management capabilities.

**Developed by Black10998**

## Features

- **Exact 1:1 Design Clone** - Pixel-perfect recreation of the original website
- **Fully Responsive** - Optimized for all devices (desktop, tablet, mobile)
- **WordPress Customizer Integration** - Edit all content from the WordPress admin
- **German Language** - All content maintained in German
- **No External Links** - All external links removed for security
- **SEO Optimized** - Clean, semantic HTML5 markup
- **Performance Optimized** - Fast loading times with optimized assets
- **Accessibility Ready** - WCAG 2.1 compliant

## Installation

1. Download the theme ZIP file: `zierhofer-wordpress-theme-v3.0.zip`
2. Log in to your WordPress admin panel
3. Navigate to **Appearance → Themes → Add New**
4. Click **Upload Theme**
5. Choose the ZIP file and click **Install Now**
6. Click **Activate** to enable the theme

## Configuration

### Theme Customizer

Access the Theme Customizer at **Appearance → Customize** to edit:

#### Company Information
- Company Name
- Company Tagline
- Phone Number
- Emergency Phone (24h)
- Email Address
- Physical Address
- Opening Hours

#### Hero Section
- Hero Title
- Hero Subtitle
- Hero Description

#### About Section
- About Title
- About Content

#### Footer Settings
- Footer Copyright Text
- Developer Credit

### Menus

Set up your navigation menus at **Appearance → Menus**:

1. **Primary Menu** - Main navigation in header
2. **Footer Menu** - Links in footer

Default menu items:
- Home
- Kontakt
- Karriere
- Notdienst

### Widgets

The theme includes 3 footer widget areas:
- Footer Widget Area 1
- Footer Widget Area 2
- Footer Widget Area 3

Configure at **Appearance → Widgets**

## Pages

The theme includes templates for the following pages:

### Homepage (Front Page)
Displays all main sections:
- Hero section with company introduction
- About section (Über uns)
- Services section (Leistungen)
  - Gasinstallateur
  - Sanitärinstallateur
  - Heizungstechnik
  - Sanierung
- Sustainability section (Nachhaltigkeit)
- Emergency service section (24 Std. Notdienst)
- Training section (Ausbildung)
- Customer types (Privatkunden / Gewerbekunden)
- Memberships (Mitgliedschaften)
- Partners (Unsere Partner)

### Additional Pages
Create these pages in WordPress:
- Kontakt (Contact)
- Karriere (Career)
- Notdienst (Emergency Service)
- Impressum (Imprint)
- Datenschutz (Privacy Policy)

## Customization

### Editing Content

All content is editable through:
1. **WordPress Customizer** - For global settings (company info, hero section, etc.)
2. **Page Editor** - For individual page content
3. **Widgets** - For footer content

### Design Customization

The theme design is fixed to maintain 1:1 visual fidelity with the original site. Layout, colors, fonts, and spacing should not be modified to preserve the exact appearance.

### Custom Logo

Upload your logo at **Appearance → Customize → Site Identity → Logo**

Recommended logo size: 300x100px (flexible dimensions supported)

## Technical Details

### Theme Structure

```
zierhofer-wordpress-theme/
├── assets/
│   ├── css/
│   │   └── fonts.css
│   ├── js/
│   │   ├── main.js
│   │   ├── navigation.js
│   │   └── customizer.js
│   ├── images/
│   │   └── [all theme images]
│   └── fonts/
│       ├── Saira_SemiCondensed-Medium.ttf
│       └── Rubik-Bold.ttf
├── inc/
│   ├── template-tags.php
│   ├── custom-functions.php
│   └── customizer.php
├── template-parts/
│   ├── content.php
│   └── content-none.php
├── style.css
├── functions.php
├── header.php
├── footer.php
├── index.php
├── front-page.php
├── page.php
└── README.md
```

### Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

### WordPress Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- MySQL 5.6 or higher

## Support

For issues or questions related to this theme, please contact the developer:

**Developer:** Black10998  
**Repository:** [https://github.com/Black10998/zierhofer-alkhala](https://github.com/Black10998/zierhofer-alkhala)

## Changelog

### Version 3.0.0 (2025-11-24)
- Initial WordPress theme release
- Complete 1:1 conversion from static HTML site
- Full WordPress Customizer integration
- Responsive design implementation
- All content editable from WordPress admin
- External links removed
- Performance optimizations
- Accessibility improvements

## Credits

**Original Website:** Sana Tec - Gas, Wasser und Heizung  
**Theme Development:** Black10998  
**Source Repository:** [https://github.com/Black10998/zierhofer-alkhala](https://github.com/Black10998/zierhofer-alkhala)

### Fonts
- Saira Semi Condensed
- Rubik

### Images
All images are property of Sana Tec and included with permission.

## License

This theme is licensed under the GNU General Public License v2 or later.

```
Copyright (C) 2025 Black10998

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
```

---

**Developed by Black10998**  
[https://github.com/Black10998/zierhofer-alkhala](https://github.com/Black10998/zierhofer-alkhala)
